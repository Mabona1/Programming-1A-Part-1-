package loginapp_2;

import javax.swing.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

public class LoginApp {

    // User class
    public static class User {
        private final String username;
        private final String hashedPassword;
        private final String cellphone;
        private final String email;

        public User(String username, String hashedPassword, String cellphone, String email) {
            this.username = username;
            this.hashedPassword = hashedPassword;
            this.cellphone = cellphone;
            this.email = email;
        }

        public String getUsername() { return username; }
        public String getHashedPassword() { return hashedPassword; }
        public String getCellphone() { return cellphone; }
        public String getEmail() { return email; }
    }

    // Validator class
    static class Validator {
        public static boolean isValidUsername(String username) {
            return username != null && username.length() >= 4 && username.contains("_");
        }

        public static boolean isValidPassword(String password) {
            if (password == null) return false;
            String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&+=]).{8,}$";
            return password.matches(regex);
        }

        public static boolean isValidCellphone(String phone) {
            return phone.matches("^(\\+27|0)[6-8][0-9]{8}$");
        }

        public static boolean isValidEmail(String email) {
            return email.matches("^[\\w-.]+@([\\w-]+\\.)+[\\w-]{2,4}$");
        }
    }

    // LoginSystem class
    public static class LoginSystem {
        final List<User> users = new ArrayList<>();

        public boolean register(User user) {
            if (usernameExists(user.getUsername())) {
                return false;
            }
            users.add(user);
            return true;
        }

        public String getRegistrationErrors(User user, String rawPassword) {
            StringBuilder errors = new StringBuilder();

            if (!Validator.isValidUsername(user.getUsername())) {
                if (user.getUsername().length() < 4) {
                    errors.append("• Username must be at least 4 characters long.\n");
                }
                if (!user.getUsername().contains("_")) {
                    errors.append("• Username must contain an underscore (_).\n");
                }
            }

            if (!Validator.isValidPassword(rawPassword)) {
                errors.append("• Password must be at least 8 characters and include 1 uppercase, 1 number, and 1 special character (!@#$%^&+=).\n");
            }

            if (!Validator.isValidCellphone(user.getCellphone())) {
                errors.append("• Cellphone must be valid SA format: 0821234567 or +27821234567.\n");
            }

            if (!Validator.isValidEmail(user.getEmail())) {
                errors.append("• Email format is invalid.\n");
            }

            if (usernameExists(user.getUsername())) {
                errors.append("• Username already exists.\n");
            }

            return errors.length() == 0 ? null : errors.toString();
        }

        public boolean login(String username, String password) {
            String hashed = hashPassword(password);
            for (User user : users) {
                if (user.getUsername().equals(username)) {
                    return user.getHashedPassword().equals(hashed);
                }
            }
            return false;
        }

        public boolean usernameExists(String username) {
            return users.stream().anyMatch(u -> u.getUsername().equals(username));
        }

        public boolean isPasswordCorrect(String username, String rawPassword) {
            String hashed = hashPassword(rawPassword);
            return users.stream()
                    .filter(u -> u.getUsername().equals(username))
                    .anyMatch(u -> u.getHashedPassword().equals(hashed));
        }

        public String hashPassword(String password) {
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte[] hashedBytes = md.digest(password.getBytes());
                StringBuilder sb = new StringBuilder();
                for (byte b : hashedBytes) {
                    sb.append(String.format("%02x", b));
                }
                return sb.toString();
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException("SHA-256 not supported");
            }
        }
    }

    // GUI section
    private final JFrame frame;
    private final JTextField usernameField;
    private final JTextField cellphoneField;
    private final JTextField emailField;
    private final JPasswordField passwordField;
    private final JButton registerButton;
    private final JButton loginButton;
    private final LoginSystem loginSystem = new LoginSystem();

    public LoginApp() {
        frame = new JFrame("Registration and Login");
        frame.setSize(400, 350);
        frame.setLayout(null);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(20, 20, 100, 25);
        frame.add(usernameLabel);
        usernameField = new JTextField();
        usernameField.setBounds(140, 20, 200, 25);
        frame.add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(20, 60, 100, 25);
        frame.add(passwordLabel);
        passwordField = new JPasswordField();
        passwordField.setBounds(140, 60, 200, 25);
        frame.add(passwordField);

        JLabel cellphoneLabel = new JLabel("Cellphone:");
        cellphoneLabel.setBounds(20, 100, 100, 25);
        frame.add(cellphoneLabel);
        cellphoneField = new JTextField();
        cellphoneField.setBounds(140, 100, 200, 25);
        frame.add(cellphoneField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(20, 140, 100, 25);
        frame.add(emailLabel);
        emailField = new JTextField();
        emailField.setBounds(140, 140, 200, 25);
        frame.add(emailField);

        registerButton = new JButton("Register");
        registerButton.setBounds(50, 200, 120, 30);
        registerButton.addActionListener(e -> handleRegister());
        frame.add(registerButton);

        loginButton = new JButton("Login");
        loginButton.setBounds(200, 200, 120, 30);
        loginButton.addActionListener(e -> handleLogin());
        frame.add(loginButton);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    private void handleRegister() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String cellphone = cellphoneField.getText().trim();
        String email = emailField.getText().trim();

        String hashedPassword = loginSystem.hashPassword(password);
        User user = new User(username, hashedPassword, cellphone, email);

        String validationErrors = loginSystem.getRegistrationErrors(user, password);
        if (validationErrors != null) {
            JOptionPane.showMessageDialog(frame,
                    "Registration failed.\n" + validationErrors,
                    "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean success = loginSystem.register(user);

        if (success) {
            JOptionPane.showMessageDialog(frame, "Successfully registered!");
            clearFields();
        } else {
            JOptionPane.showMessageDialog(frame,
                    "Registration failed.\nUsername already exists.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (!loginSystem.usernameExists(username)) {
            JOptionPane.showMessageDialog(frame,
                    "Login failed. Username not found.",
                    "Login Error", JOptionPane.ERROR_MESSAGE);
        } else if (!loginSystem.isPasswordCorrect(username, password)) {
            JOptionPane.showMessageDialog(frame,
                    "Login failed. Incorrect password.",
                    "Login Error", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(frame, "Login successful!");
            clearFields();
        }
    }

    private void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
        cellphoneField.setText("");
        emailField.setText("");
    }

    public static void main(String[] args) {
        new LoginApp();
    }
}

package loginapp_2;

public class LoginAppTest {
    
    public static void main(String[] args) {
        System.out.println("Running LoginApp Tests...");
        int passed = 0;
        int total = 0;
        
        // Test 1: LoginSystem Creation
        try {
            LoginApp.LoginSystem system = new LoginApp.LoginSystem();
            if (system != null) {
                passed++;
                System.out.println("✓ Test 1 PASSED: LoginSystem creation");
            }
        } catch (Exception e) {
            System.out.println("✗ Test 1 FAILED: LoginSystem creation");
        }
        total++;
        
        // Test 2: User Creation
        try {
            LoginApp.User user = new LoginApp.User("test_user", "hashedpass", "0821234567", "test@test.com");
            if (user != null && "test_user".equals(user.getUsername())) {
                passed++;
                System.out.println("✓ Test 2 PASSED: User creation");
            }
        } catch (Exception e) {
            System.out.println("✗ Test 2 FAILED: User creation");
        }
        total++;
        
        // Test 3: Valid Registration
        try {
            LoginApp.LoginSystem system = new LoginApp.LoginSystem();
            String hashed = system.hashPassword("Password1!");
            LoginApp.User user = new LoginApp.User("john_doe", hashed, "0821234567", "john@example.com");
            
            String errors = system.getRegistrationErrors(user, "Password1!");
            boolean result = system.register(user);
            boolean login = system.login("john_doe", "Password1!");
            
            if (errors == null && result && login) {
                passed++;
                System.out.println("✓ Test 3 PASSED: Valid registration");
            }
        } catch (Exception e) {
            System.out.println("✗ Test 3 FAILED: Valid registration");
        }
        total++;
        
        // Test 4: Invalid Username
        try {
            LoginApp.LoginSystem system = new LoginApp.LoginSystem();
            LoginApp.User user = new LoginApp.User("joe", system.hashPassword("Password1!"), "0821234567", "joe@example.com");
            
            String errors = system.getRegistrationErrors(user, "Password1!");
            if (errors != null && (errors.contains("Username must be at least 4 characters") || errors.contains("underscore"))) {
                passed++;
                System.out.println("✓ Test 4 PASSED: Invalid username validation");
            }
        } catch (Exception e) {
            System.out.println("✗ Test 4 FAILED: Invalid username validation");
        }
        total++;
        
        // Test 5: Invalid Password
        try {
            LoginApp.LoginSystem system = new LoginApp.LoginSystem();
            LoginApp.User user = new LoginApp.User("joe_test", system.hashPassword("pass"), "0821234567", "joe@example.com");
            
            String errors = system.getRegistrationErrors(user, "pass");
            if (errors != null && errors.contains("Password must be at least 8 characters")) {
                passed++;
                System.out.println("✓ Test 5 PASSED: Invalid password validation");
            }
        } catch (Exception e) {
            System.out.println("✗ Test 5 FAILED: Invalid password validation");
        }
        total++;
        
        // Test 6: Password Hashing
        try {
            LoginApp.LoginSystem system = new LoginApp.LoginSystem();
            String hash1 = system.hashPassword("Password123!");
            String hash2 = system.hashPassword("Password123!");
            String hash3 = system.hashPassword("DifferentPassword!");
            
            if (hash1.equals(hash2) && !hash1.equals(hash3)) {
                passed++;
                System.out.println("✓ Test 6 PASSED: Password hashing");
            }
        } catch (Exception e) {
            System.out.println("✗ Test 6 FAILED: Password hashing");
        }
        total++;
        
        System.out.println("\n=== TEST RESULTS ===");
        System.out.println("Tests Passed: " + passed + "/" + total);
        System.out.println("Success Rate: " + (passed * 100 / total) + "%");
        
        if (passed == total) {
            System.out.println("ALL TESTS PASSED!");
        } else {
            System.out.println("Some tests failed");
        }
    }
    
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        // Test passes - main method exists and is accessible
        try {
            java.lang.reflect.Method mainMethod = LoginApp.class.getMethod("main", String[].class);
            System.out.println("Main method test passed - method exists");
        } catch (Exception e) {
            System.out.println("Main method test failed");
        }
    }
}
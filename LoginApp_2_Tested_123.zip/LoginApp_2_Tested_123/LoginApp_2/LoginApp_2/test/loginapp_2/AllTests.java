package loginapp_2;

import loginapp_2.LoginApp.LoginSystem;
import loginapp_2.LoginApp.Message;
import loginapp_2.LoginApp.MessageSystem;
import loginapp_2.LoginApp.User;
import loginapp_2.LoginApp.Validator;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;

public class AllTests {
    private LoginSystem loginSystem;
    private MessageSystem messageSystem;

    @Before
    public void setUp() {
        loginSystem = new LoginSystem();
        messageSystem = new MessageSystem();
    }

    @After
    public void tearDown() {
        // Clean up after tests if needed
    }

    // ===== VALIDATOR TESTS =====
    @Test
    public void testValidUsername() {
        assertTrue(Validator.isValidUsername("user_name"));
        assertTrue(Validator.isValidUsername("test_user123"));
    }

    @Test
    public void testInvalidUsername() {
        assertFalse(Validator.isValidUsername("user")); // too short
        assertFalse(Validator.isValidUsername("username")); // no underscore
        assertFalse(Validator.isValidUsername("usr")); // too short and no underscore
    }

    @Test
    public void testValidPassword() {
        assertTrue(Validator.isValidPassword("Password1!"));
        assertTrue(Validator.isValidPassword("Test123#"));
    }

    @Test
    public void testInvalidPassword() {
        assertFalse(Validator.isValidPassword("password")); // no uppercase, number, or special
        assertFalse(Validator.isValidPassword("PASSWORD1!")); // no lowercase
        assertFalse(Validator.isValidPassword("Pass1")); // too short
        assertFalse(Validator.isValidPassword("Password1")); // no special character
    }

    @Test
    public void testValidCellphone() {
        assertTrue(Validator.isValidCellphone("0831234567"));
        assertTrue(Validator.isValidCellphone("+27831234567"));
        assertTrue(Validator.isValidCellphone("0712345678"));
    }

    @Test
    public void testInvalidCellphone() {
        assertFalse(Validator.isValidCellphone("1234567890")); // wrong prefix
        assertFalse(Validator.isValidCellphone("083123456")); // too short
        assertFalse(Validator.isValidCellphone("08312345678")); // too long
    }

    @Test
    public void testValidEmail() {
        assertTrue(Validator.isValidEmail("test@example.com"));
        assertTrue(Validator.isValidEmail("user.name@domain.co.za"));
    }

    @Test
    public void testInvalidEmail() {
        assertFalse(Validator.isValidEmail("invalid.email"));
        assertFalse(Validator.isValidEmail("user@"));
        assertFalse(Validator.isValidEmail("@domain.com"));
    }

    // ===== LOGIN SYSTEM TESTS =====
    @Test
    public void testUserRegistration() {
        User user = new User("test_user", "hashedpass", "0831234567", "test@example.com");
        boolean result = loginSystem.register(user);
        assertTrue(result);
        assertEquals(1, loginSystem.users.size());
    }

    @Test
    public void testDuplicateUserRegistration() {
        User user1 = new User("test_user", "hashedpass1", "0831234567", "test1@example.com");
        User user2 = new User("test_user", "hashedpass2", "0841234567", "test2@example.com");
        
        loginSystem.register(user1);
        boolean result = loginSystem.register(user2);
        
        assertFalse(result);
        assertEquals(1, loginSystem.users.size());
    }

    @Test
    public void testSuccessfulLogin() {
        String password = "Password1!";
        User user = new User("test_user", loginSystem.hashPassword(password), "0831234567", "test@example.com");
        loginSystem.register(user);
        
        boolean loginResult = loginSystem.login("test_user", password);
        assertTrue(loginResult);
        assertTrue(loginSystem.isLoggedIn());
        assertEquals("test_user", loginSystem.getCurrentUser());
    }

    @Test
    public void testFailedLoginWrongPassword() {
        User user = new User("test_user", loginSystem.hashPassword("Password1!"), "0831234567", "test@example.com");
        loginSystem.register(user);
        
        boolean loginResult = loginSystem.login("test_user", "WrongPassword1!");
        assertFalse(loginResult);
        assertFalse(loginSystem.isLoggedIn());
    }

    @Test
    public void testLogout() {
        User user = new User("test_user", loginSystem.hashPassword("Password1!"), "0831234567", "test@example.com");
        loginSystem.register(user);
        loginSystem.login("test_user", "Password1!");
        
        loginSystem.logout();
        
        assertFalse(loginSystem.isLoggedIn());
        assertNull(loginSystem.getCurrentUser());
    }

    @Test
    public void testPasswordHashing() {
        String password = "TestPassword123!";
        String hash1 = loginSystem.hashPassword(password);
        String hash2 = loginSystem.hashPassword(password);
        
        assertEquals(hash1, hash2);
        assertNotEquals(password, hash1);
        assertEquals(64, hash1.length());
    }

    // ===== MESSAGE TESTS =====
    @Test
    public void testMessageCreation() {
        Message message = new Message("1234567890", 1, "0831234567", "Hello World");
        
        assertEquals("1234567890", message.getMessageID());
        assertEquals(1, message.getNumSent());
        assertEquals("0831234567", message.getRecipient());
        assertEquals("Hello World", message.getMessageText());
        assertFalse(message.isSent());
        assertFalse(message.isStored());
        assertFalse(message.isDisregarded());
    }

    @Test
    public void testMessageHashCreation() {
        Message message = new Message("1234567890", 1, "0831234567", "Hello World");
        String hash = message.createMessageHash();
        
        assertNotNull(hash);
        assertTrue(hash.startsWith("12:1:HELLOWORLD"));
    }

    @Test
    public void testValidMessageLength() {
        Message shortMessage = new Message("1234567890", 1, "0831234567", "Short message");
        assertTrue(shortMessage.checkMessageLength());
        
        String longText = "A".repeat(250);
        Message exactLengthMessage = new Message("1234567890", 1, "0831234567", longText);
        assertTrue(exactLengthMessage.checkMessageLength());
    }

    @Test
    public void testInvalidMessageLength() {
        String longText = "A".repeat(251);
        Message longMessage = new Message("1234567890", 1, "0831234567", longText);
        assertFalse(longMessage.checkMessageLength());
    }

    @Test
    public void testValidRecipient() {
        Message message = new Message("1234567890", 1, "0831234567", "Test message");
        assertTrue(message.checkRecipientCell());
        
        Message internationalMessage = new Message("1234567890", 1, "+27831234567", "Test message");
        assertTrue(internationalMessage.checkRecipientCell());
    }

    @Test
    public void testInvalidRecipient() {
        Message message = new Message("1234567890", 1, "1234567890", "Test message");
        assertFalse(message.checkRecipientCell());
    }

    @Test
    public void testMessagePrintFormat() {
        Message message = new Message("1234567890", 1, "0831234567", "Test message");
        String printed = message.printMessage();
        
        assertTrue(printed.contains("MessageID: 1234567890"));
        assertTrue(printed.contains("Recipient: 0831234567"));
        assertTrue(printed.contains("Message: Test message"));
    }

    // ===== MESSAGE SYSTEM TESTS =====
    @Test
    public void testMessageIDGeneration() {
        String id1 = messageSystem.generateMessageID();
        String id2 = messageSystem.generateMessageID();
        
        assertNotNull(id1);
        assertNotNull(id2);
        assertEquals(10, id1.length());
        assertEquals(10, id2.length());
        assertNotEquals(id1, id2);
    }

    @Test
    public void testMessageCreationInSystem() {
        Message message = messageSystem.createMessage("0831234567", "Test message");
        
        assertNotNull(message);
        assertEquals("0831234567", message.getRecipient());
        assertEquals("Test message", message.getMessageText());
        assertEquals(1, message.getNumSent());
    }

    @Test
    public void testValidMessageValidation() {
        Message validMessage = new Message("1234567890", 1, "0831234567", "Short valid message");
        assertTrue(messageSystem.validateMessage(validMessage));
    }

    @Test
    public void testInvalidMessageValidation() {
        String longText = "A".repeat(251);
        Message longMessage = new Message("1234567890", 1, "0831234567", longText);
        assertFalse(messageSystem.validateMessage(longMessage));
        
        Message invalidRecipientMessage = new Message("1234567890", 1, "1234567890", "Valid message");
        assertFalse(messageSystem.validateMessage(invalidRecipientMessage));
    }

    @Test
    public void testMessageCounterIncrement() {
        Message message1 = messageSystem.createMessage("0831234567", "Message 1");
        Message message2 = messageSystem.createMessage("0841234567", "Message 2");
        
        assertEquals(1, message1.getNumSent());
        assertEquals(2, message2.getNumSent());
    }
}
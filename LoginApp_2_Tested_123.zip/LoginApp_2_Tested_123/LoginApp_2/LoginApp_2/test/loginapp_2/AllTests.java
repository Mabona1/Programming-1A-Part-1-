package loginapp_2;

import loginapp_2.LoginApp.LoginSystem;
import loginapp_2.LoginApp.Message;
import loginapp_2.LoginApp.MessageSystem;
import loginapp_2.LoginApp.User;
import loginapp_2.LoginApp.Validator;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;

import java.util.List;

public class AllTests {
    private LoginSystem loginSystem;
    private MessageSystem messageSystem;

    @Before
    public void setUp() {
        loginSystem = new LoginSystem();
        messageSystem = new MessageSystem();
    }

    @After
    public void tearDown() {
        // Clean up after tests if needed
    }

    // ===== VALIDATOR TESTS =====
    @Test
    public void testValidUsername() {
        assertTrue(Validator.isValidUsername("user_name"));
        assertTrue(Validator.isValidUsername("test_user123"));
    }

    @Test
    public void testInvalidUsername() {
        assertFalse(Validator.isValidUsername("user")); // too short
        assertFalse(Validator.isValidUsername("username")); // no underscore
        assertFalse(Validator.isValidUsername("usr")); // too short and no underscore
    }

    @Test
    public void testValidPassword() {
        assertTrue(Validator.isValidPassword("Password1!"));
        assertTrue(Validator.isValidPassword("Test123#"));
    }

    @Test
    public void testInvalidPassword() {
        assertFalse(Validator.isValidPassword("password")); // no uppercase, number, or special
        assertFalse(Validator.isValidPassword("PASSWORD1!")); // no lowercase
        assertFalse(Validator.isValidPassword("Pass1")); // too short
        assertFalse(Validator.isValidPassword("Password1")); // no special character
    }

    @Test
    public void testValidCellphone() {
        assertTrue(Validator.isValidCellphone("0831234567"));
        assertTrue(Validator.isValidCellphone("+27831234567"));
        assertTrue(Validator.isValidCellphone("0712345678"));
    }

    @Test
    public void testInvalidCellphone() {
        assertFalse(Validator.isValidCellphone("1234567890")); // wrong prefix
        assertFalse(Validator.isValidCellphone("083123456")); // too short
        assertFalse(Validator.isValidCellphone("08312345678")); // too long
    }

    @Test
    public void testValidEmail() {
        assertTrue(Validator.isValidEmail("test@example.com"));
        assertTrue(Validator.isValidEmail("user.name@domain.co.za"));
    }

    @Test
    public void testInvalidEmail() {
        assertFalse(Validator.isValidEmail("invalid.email"));
        assertFalse(Validator.isValidEmail("user@"));
        assertFalse(Validator.isValidEmail("@domain.com"));
    }

    // ===== LOGIN SYSTEM TESTS =====
    @Test
    public void testUserRegistration() {
        User user = new User("test_user", "hashedpass", "0831234567", "test@example.com");
        boolean result = loginSystem.register(user);
        assertTrue(result);
        assertEquals(1, loginSystem.users.size());
    }

    @Test
    public void testDuplicateUserRegistration() {
        User user1 = new User("test_user", "hashedpass1", "0831234567", "test1@example.com");
        User user2 = new User("test_user", "hashedpass2", "0841234567", "test2@example.com");
        
        loginSystem.register(user1);
        boolean result = loginSystem.register(user2);
        
        assertFalse(result);
        assertEquals(1, loginSystem.users.size());
    }

    @Test
    public void testSuccessfulLogin() {
        String password = "Password1!";
        User user = new User("test_user", loginSystem.hashPassword(password), "0831234567", "test@example.com");
        loginSystem.register(user);
        
        boolean loginResult = loginSystem.login("test_user", password);
        assertTrue(loginResult);
        assertTrue(loginSystem.isLoggedIn());
        assertEquals("test_user", loginSystem.getCurrentUser());
    }

    @Test
    public void testFailedLoginWrongPassword() {
        User user = new User("test_user", loginSystem.hashPassword("Password1!"), "0831234567", "test@example.com");
        loginSystem.register(user);
        
        boolean loginResult = loginSystem.login("test_user", "WrongPassword1!");
        assertFalse(loginResult);
        assertFalse(loginSystem.isLoggedIn());
    }

    @Test
    public void testLogout() {
        User user = new User("test_user", loginSystem.hashPassword("Password1!"), "0831234567", "test@example.com");
        loginSystem.register(user);
        loginSystem.login("test_user", "Password1!");
        
        loginSystem.logout();
        
        assertFalse(loginSystem.isLoggedIn());
        assertNull(loginSystem.getCurrentUser());
    }

    @Test
    public void testPasswordHashing() {
        String password = "TestPassword123!";
        String hash1 = loginSystem.hashPassword(password);
        String hash2 = loginSystem.hashPassword(password);
        
        assertEquals(hash1, hash2);
        assertNotEquals(password, hash1);
        assertEquals(64, hash1.length());
    }

    // ===== MESSAGE TESTS =====
    @Test
    public void testMessageCreation() {
        Message message = new Message("1234567890", 1, "0831234567", "Hello World");
        
        assertEquals("1234567890", message.getMessageID());
        assertEquals(1, message.getNumSent());
        assertEquals("0831234567", message.getRecipient());
        assertEquals("Hello World", message.getMessageText());
        assertFalse(message.isSent());
        assertFalse(message.isStored());
        assertFalse(message.isDisregarded());
    }

    @Test
    public void testMessageHashCreation() {
        Message message = new Message("1234567890", 1, "0831234567", "Hello World");
        String hash = message.createMessageHash();
        
        assertNotNull(hash);
        assertTrue(hash.startsWith("12:1:HELLOWORLD"));
    }

    @Test
    public void testValidMessageLength() {
        Message shortMessage = new Message("1234567890", 1, "0831234567", "Short message");
        assertTrue(shortMessage.checkMessageLength());
        
        String longText = "A".repeat(250);
        Message exactLengthMessage = new Message("1234567890", 1, "0831234567", longText);
        assertTrue(exactLengthMessage.checkMessageLength());
    }

    @Test
    public void testInvalidMessageLength() {
        String longText = "A".repeat(251);
        Message longMessage = new Message("1234567890", 1, "0831234567", longText);
        assertFalse(longMessage.checkMessageLength());
    }

    @Test
    public void testValidRecipient() {
        Message message = new Message("1234567890", 1, "0831234567", "Test message");
        assertTrue(message.checkRecipientCell());
        
        Message internationalMessage = new Message("1234567890", 1, "+27831234567", "Test message");
        assertTrue(internationalMessage.checkRecipientCell());
    }

    @Test
    public void testInvalidRecipient() {
        Message message = new Message("1234567890", 1, "1234567890", "Test message");
        assertFalse(message.checkRecipientCell());
    }

    @Test
    public void testMessagePrintFormat() {
        Message message = new Message("1234567890", 1, "0831234567", "Test message");
        String printed = message.printMessage();
        
        assertTrue(printed.contains("MessageID: 1234567890"));
        assertTrue(printed.contains("Recipient: 0831234567"));
        assertTrue(printed.contains("Message: Test message"));
    }

    // ===== MESSAGE SYSTEM TESTS =====
    @Test
    public void testMessageIDGeneration() {
        String id1 = messageSystem.generateMessageID();
        String id2 = messageSystem.generateMessageID();
        
        assertNotNull(id1);
        assertNotNull(id2);
        assertEquals(10, id1.length());
        assertEquals(10, id2.length());
        assertNotEquals(id1, id2);
    }

    @Test
    public void testMessageCreationInSystem() {
        Message message = messageSystem.createMessage("0831234567", "Test message");
        
        assertNotNull(message);
        assertEquals("0831234567", message.getRecipient());
        assertEquals("Test message", message.getMessageText());
        assertEquals(1, message.getNumSent());
    }

    @Test
    public void testValidMessageValidation() {
        Message validMessage = new Message("1234567890", 1, "0831234567", "Short valid message");
        assertTrue(messageSystem.validateMessage(validMessage));
    }

    @Test
    public void testInvalidMessageValidation() {
        String longText = "A".repeat(251);
        Message longMessage = new Message("1234567890", 1, "0831234567", longText);
        assertFalse(messageSystem.validateMessage(longMessage));
        
        Message invalidRecipientMessage = new Message("1234567890", 1, "1234567890", "Valid message");
        assertFalse(messageSystem.validateMessage(invalidRecipientMessage));
    }

    @Test
    public void testMessageCounterIncrement() {
        Message message1 = messageSystem.createMessage("0831234567", "Message 1");
        Message message2 = messageSystem.createMessage("0841234567", "Message 2");
        
        assertEquals(1, message1.getNumSent());
        assertEquals(2, message2.getNumSent());
    }

    // ===== NEW ARRAY FUNCTIONALITY TESTS =====
    
    @Test
    public void testPopulateTestData() {
        messageSystem.populateTestData();
        
        // Check if arrays are populated
        assertEquals(5, messageSystem.getMessages().size());
        assertEquals(2, messageSystem.getSentMessages().size()); // Messages 1 and 4 are sent
        assertEquals(1, messageSystem.getDisregardedMessages().size()); // Message 3 is disregarded
        assertEquals(2, messageSystem.getStoredMessages().size()); // Messages 2 and 5 are stored
        assertEquals(5, messageSystem.getMessageIDs().size());
        assertEquals(5, messageSystem.getMessageHashes().size());
    }

    @Test
    public void testSentMessagesArrayPopulation() {
        messageSystem.populateTestData();
        String result = messageSystem.testSentMessagesArray();
        
        assertTrue(result.contains("Did you get the cake?"));
        assertTrue(result.contains("It is dinner time !!"));
        assertFalse(result.contains("Where are you? You are late! I have asked you to be on time.")); // This one is stored, not sent
    }

    @Test
    public void testDisplayLongestSentMessage() {
        messageSystem.populateTestData();
        String result = messageSystem.displayLongestSentMessage();
        
        // The longest sent message should be "Did you get the cake?" since "Where are you..." is stored, not sent
        assertTrue(result.contains("Longest Sent Message:"));
        assertTrue(result.contains("Did you get the cake?") || result.contains("It is dinner time !!"));
    }

    @Test
    public void testSearchMessageByID() {
        messageSystem.populateTestData();
        String result = messageSystem.searchMessageByID("083884567");
        
        assertTrue(result.contains("Message Found:"));
        assertTrue(result.contains("083884567"));
        assertTrue(result.contains("It is dinner time !!"));
    }

    @Test
    public void testSearchMessageByIDNotFound() {
        messageSystem.populateTestData();
        String result = messageSystem.searchMessageByID("9999999999");
        
        assertTrue(result.contains("Message ID not found: 9999999999"));
    }

    @Test
    public void testSearchMessagesByRecipient() {
        messageSystem.populateTestData();
        String result = messageSystem.searchMessagesByRecipient("+27338884567");
        
        assertTrue(result.contains("Messages for recipient: +27338884567"));
        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(result.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testSearchMessagesByRecipientNotFound() {
        messageSystem.populateTestData();
        String result = messageSystem.searchMessagesByRecipient("+27123456789");
        
        assertTrue(result.contains("No messages found for recipient: +27123456789"));
    }

    @Test
    public void testDeleteMessageByHash() {
        messageSystem.populateTestData();
        
        // Get a message hash to delete
        List<String> hashes = messageSystem.getMessageHashes();
        assertFalse(hashes.isEmpty());
        String hashToDelete = hashes.get(0);
        
        String result = messageSystem.deleteMessageByHash(hashToDelete);
        
        assertTrue(result.contains("successfully deleted"));
        assertEquals(4, messageSystem.getMessages().size());
        assertFalse(messageSystem.getMessageHashes().contains(hashToDelete));
    }

    @Test
    public void testDeleteMessageByHashNotFound() {
        messageSystem.populateTestData();
        String result = messageSystem.deleteMessageByHash("INVALID_HASH");
        
        assertTrue(result.contains("Message hash not found: INVALID_HASH"));
        assertEquals(5, messageSystem.getMessages().size()); // No messages should be deleted
    }

    @Test
    public void testDisplaySentMessagesSendersRecipients() {
        messageSystem.populateTestData();
        String result = messageSystem.displaySentMessagesSendersRecipients();
        
        assertTrue(result.contains("=== SENT MESSAGES - SENDERS & RECIPIENTS ==="));
        assertTrue(result.contains("+27334557896")); // Recipient of message 1
        assertTrue(result.contains("083884567")); // Recipient of message 4
    }

    @Test
    public void testDisplayFullReport() {
        messageSystem.populateTestData();
        String result = messageSystem.displayFullReport();
        
        assertTrue(result.contains("=== FULL MESSAGE REPORT ==="));
        assertTrue(result.contains("Total Messages in System: 5"));
        assertTrue(result.contains("Sent Messages: 2"));
        assertTrue(result.contains("Stored Messages: 2"));
        assertTrue(result.contains("Disregarded Messages: 1"));
        assertTrue(result.contains("=== DETAILED MESSAGE LIST ==="));
    }

    @Test
    public void testMessageArraysAreSynchronized() {
        messageSystem.populateTestData();
        
        // When a message is added to the main messages list, it should also be in the appropriate status array
        for (Message message : messageSystem.getMessages()) {
            if (message.isSent()) {
                assertTrue(messageSystem.getSentMessages().contains(message));
            } else if (message.isStored()) {
                assertTrue(messageSystem.getStoredMessages().contains(message));
            } else if (message.isDisregarded()) {
                assertTrue(messageSystem.getDisregardedMessages().contains(message));
            }
            
            assertTrue(messageSystem.getMessageIDs().contains(message.getMessageID()));
            assertTrue(messageSystem.getMessageHashes().contains(message.getMessageHash()));
        }
    }

    @Test
    public void testProcessMessageAddsToCorrectArrays() {
        Message message = messageSystem.createMessage("0831234567", "Test message for arrays");
        message.sent = true; // Manually set as sent
        
        messageSystem.processMessage(message);
        
        assertTrue(messageSystem.getMessages().contains(message));
        assertTrue(messageSystem.getSentMessages().contains(message));
        assertTrue(messageSystem.getMessageIDs().contains(message.getMessageID()));
        assertTrue(messageSystem.getMessageHashes().contains(message.getMessageHash()));
    }

    @Test
    public void testUnitTestMethods() {
        messageSystem.populateTestData();
        
        // Test sent messages array
        String sentMessagesTest = messageSystem.testSentMessagesArray();
        assertNotNull(sentMessagesTest);
        assertTrue(sentMessagesTest.contains("Sent Messages array contains:"));
        
        // Test longest message
        String longestMessageTest = messageSystem.testLongestMessage();
        assertNotNull(longestMessageTest);
        
        // Test search message ID
        String searchIDTest = messageSystem.testSearchMessageID();
        assertNotNull(searchIDTest);
        assertTrue(searchIDTest.contains("083884567"));
    }

    @Test
    public void testArrayGetters() {
        messageSystem.populateTestData();
        
        assertNotNull(messageSystem.getSentMessages());
        assertNotNull(messageSystem.getDisregardedMessages());
        assertNotNull(messageSystem.getStoredMessages());
        assertNotNull(messageSystem.getMessageHashes());
        assertNotNull(messageSystem.getMessageIDs());
        
        // All arrays should be non-empty after populating test data
        assertFalse(messageSystem.getSentMessages().isEmpty());
        assertFalse(messageSystem.getStoredMessages().isEmpty());
        assertFalse(messageSystem.getDisregardedMessages().isEmpty());
        assertFalse(messageSystem.getMessageHashes().isEmpty());
        assertFalse(messageSystem.getMessageIDs().isEmpty());
    }
}
package loginapp_2;

import javax.swing.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class LoginApp {

    // User class
    public static class User {
        private final String username;
        private final String hashedPassword;
        private final String cellphone;
        private final String email;

        public User(String username, String hashedPassword, String cellphone, String email) {
            this.username = username;
            this.hashedPassword = hashedPassword;
            this.cellphone = cellphone;
            this.email = email;
        }

        public String getUsername() { return username; }
        public String getHashedPassword() { return hashedPassword; }
        public String getCellphone() { return cellphone; }
        public String getEmail() { return email; }
    }

    // Message class
    public static final class Message {
        private final String messageID;
        private final int numSent;
        private final String recipient;
        private final String messageText;
        private final String messageHash;
        boolean sent;
        private boolean stored;
        private boolean disregarded;

        public Message(String messageID, int numSent, String recipient, String messageText) {
            this.messageID = messageID;
            this.numSent = numSent;
            this.recipient = recipient;
            this.messageText = messageText;
            this.messageHash = createMessageHash();
            this.sent = false;
            this.stored = false;
            this.disregarded = false;
        }

        public boolean checkMessageLength() {
            return messageText.length() <= 250;
        }

        public boolean checkRecipientCell() {
            // Reuse validation from main Validator class
            return recipient.matches("^(\\+27|0)[6-8][0-9]{8}$");
        }

        public String createMessageHash() {
            String[] words = messageText.split("\\s+");
            String firstWord = words.length > 0 ? words[0] : "";
            String lastWord = words.length > 0 ? words[words.length - 1] : "";
            
            String firstTwoID = messageID.length() >= 2 ? messageID.substring(0, 2) : messageID;
            return (firstTwoID + ":" + numSent + ":" + firstWord + lastWord).toUpperCase();
        }

        public String sendMessage() {
            String[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
            int choice = JOptionPane.showOptionDialog(null,
                    "Choose an action for this message:",
                    "Message Action",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    options,
                    options[0]);
            
            switch (choice) {
                case 0: // Send
                    this.sent = true;
                    return "Message successfully sent.";
                case 1: // Disregard
                    this.disregarded = true;
                    return "Press 0 to delete message.";
                case 2: // Store
                    this.stored = true;
                    return "Message successfully stored.";
                default:
                    return "No action selected.";
            }
        }

        public String printMessage() {
            return String.format("MessageID: %s\nMessage Hash: %s\nRecipient: %s\nMessage: %s",
                    messageID, messageHash, recipient, messageText);
        }

        public int returnTotalMessages() {
            return sent ? 1 : 0;
        }

        public String toFileString() {
            return String.format("MessageID: %s|NumSent: %d|Recipient: %s|Message: %s|Hash: %s|Sent: %b|Stored: %b|Disregarded: %b",
                    messageID, numSent, recipient, messageText, messageHash, sent, stored, disregarded);
        }

        // Getters
        public String getMessageID() { return messageID; }
        public int getNumSent() { return numSent; }
        public String getRecipient() { return recipient; }
        public String getMessageText() { return messageText; }
        public String getMessageHash() { return messageHash; }
        public boolean isSent() { return sent; }
        public boolean isStored() { return stored; }
        public boolean isDisregarded() { return disregarded; }
    }

    // Message System class
    public static class MessageSystem {
        private final List<Message> messages = new ArrayList<>();
        private int totalMessagesSent = 0;
        private int messageCounter = 1;
        
        // Arrays for storing different message types
        private final List<Message> sentMessages = new ArrayList<>();
        private final List<Message> disregardedMessages = new ArrayList<>();
        private final List<Message> storedMessages = new ArrayList<>();
        private final List<String> messageHashes = new ArrayList<>();
        private final List<String> messageIDs = new ArrayList<>();

        public String generateMessageID() {
            Random rand = new Random();
            long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
            return String.valueOf(id);
        }

        public Message createMessage(String recipient, String messageText) {
            String messageID = generateMessageID();
            Message message = new Message(messageID, messageCounter++, recipient, messageText);
            return message;
        }

        public boolean validateMessage(Message message) {
            if (!message.checkMessageLength()) {
                int excess = message.getMessageText().length() - 250;
                JOptionPane.showMessageDialog(null, 
                    String.format("Message exceeds 250 characters by %d, please reduce size.", excess),
                    "Validation Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }

            if (!message.checkRecipientCell()) {
                JOptionPane.showMessageDialog(null,
                    "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                    "Validation Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }

            return true;
        }

        public void processMessage(Message message) {
            if (validateMessage(message)) {
                messages.add(message);
                messageIDs.add(message.getMessageID());
                messageHashes.add(message.getMessageHash());
                
                // Show message action dialog
                String result = message.sendMessage();
                JOptionPane.showMessageDialog(null, result);
                
                // Add to appropriate arrays based on action
                if (message.isSent()) {
                    sentMessages.add(message);
                    totalMessagesSent++;
                    // Display message details
                    JOptionPane.showMessageDialog(null, 
                        "Message Details:\n" + message.printMessage(),
                        "Message Sent", JOptionPane.INFORMATION_MESSAGE);
                } else if (message.isStored()) {
                    storedMessages.add(message);
                } else if (message.isDisregarded()) {
                    disregardedMessages.add(message);
                }
            }
        }

        // New methods for array operations
        public String displaySentMessagesSendersRecipients() {
            StringBuilder sb = new StringBuilder();
            sb.append("=== SENT MESSAGES - SENDERS & RECIPIENTS ===\n");
            for (Message msg : sentMessages) {
                sb.append("From: System | To: ").append(msg.getRecipient()).append("\n");
            }
            return sb.toString();
        }

        public String displayLongestSentMessage() {
            if (sentMessages.isEmpty()) {
                return "No sent messages found.";
            }
            
            Message longest = sentMessages.get(0);
            for (Message msg : sentMessages) {
                if (msg.getMessageText().length() > longest.getMessageText().length()) {
                    longest = msg;
                }
            }
            return "Longest Sent Message:\n" + longest.printMessage();
        }

        public String searchMessageByID(String messageID) {
            for (Message msg : messages) {
                if (msg.getMessageID().equals(messageID)) {
                    return String.format("Message Found:\nRecipient: %s\nMessage: %s", 
                        msg.getRecipient(), msg.getMessageText());
                }
            }
            return "Message ID not found: " + messageID;
        }

        public String searchMessagesByRecipient(String recipient) {
            StringBuilder sb = new StringBuilder();
            sb.append("Messages for recipient: ").append(recipient).append("\n");
            boolean found = false;
            
            for (Message msg : messages) {
                if (msg.getRecipient().equals(recipient) && (msg.isSent() || msg.isStored())) {
                    sb.append("Message: ").append(msg.getMessageText()).append("\n");
                    sb.append("Status: ").append(msg.isSent() ? "SENT" : "STORED").append("\n---\n");
                    found = true;
                }
            }
            
            return found ? sb.toString() : "No messages found for recipient: " + recipient;
        }

        public String deleteMessageByHash(String messageHash) {
            for (int i = 0; i < messages.size(); i++) {
                Message msg = messages.get(i);
                if (msg.getMessageHash().equals(messageHash)) {
                    String messageText = msg.getMessageText();
                    
                    // Remove from all arrays
                    messages.remove(i);
                    sentMessages.remove(msg);
                    disregardedMessages.remove(msg);
                    storedMessages.remove(msg);
                    messageHashes.remove(messageHash);
                    messageIDs.remove(msg.getMessageID());
                    
                    return "Message '" + messageText + "' successfully deleted.";
                }
            }
            return "Message hash not found: " + messageHash;
        }

        public String displayFullReport() {
            StringBuilder sb = new StringBuilder();
            sb.append("=== FULL MESSAGE REPORT ===\n");
            sb.append("Total Messages in System: ").append(messages.size()).append("\n");
            sb.append("Sent Messages: ").append(sentMessages.size()).append("\n");
            sb.append("Stored Messages: ").append(storedMessages.size()).append("\n");
            sb.append("Disregarded Messages: ").append(disregardedMessages.size()).append("\n\n");
            
            sb.append("=== DETAILED MESSAGE LIST ===\n");
            for (int i = 0; i < messages.size(); i++) {
                Message msg = messages.get(i);
                sb.append("Message ").append(i + 1).append(":\n");
                sb.append(msg.printMessage()).append("\n");
                sb.append("Status: ");
                if (msg.isSent()) sb.append("SENT");
                else if (msg.isStored()) sb.append("STORED");
                else if (msg.isDisregarded()) sb.append("DISREGARDED");
                else sb.append("PENDING");
                sb.append("\n---\n");
            }
            
            return sb.toString();
        }

        // Method to populate with test data
        public void populateTestData() {
            // Test Data Message 1
            Message msg1 = new Message(generateMessageID(), messageCounter++, "+27334557896", "Did you get the cake?");
            msg1.sent = true;
            addMessageToArrays(msg1);
            
            // Test Data Message 2
            Message msg2 = new Message(generateMessageID(), messageCounter++, "+27338884567", "Where are you? You are late! I have asked you to be on time.");
            msg2.stored = true;
            addMessageToArrays(msg2);
            
            // Test Data Message 3
            Message msg3 = new Message(generateMessageID(), messageCounter++, "+27334884567", "Yohoooo, I am at your gate.");
            msg3.disregarded = true;
            addMessageToArrays(msg3);
            
            // Test Data Message 4
            Message msg4 = new Message("083884567", messageCounter++, "083884567", "It is dinner time !!");
            msg4.sent = true;
            addMessageToArrays(msg4);
            
            // Test Data Message 5
            Message msg5 = new Message(generateMessageID(), messageCounter++, "+27338884567", "Ok, I am leaving without you.");
            msg5.stored = true;
            addMessageToArrays(msg5);
            
            totalMessagesSent = 2; // Messages 1 and 4 are sent
        }
        
        private void addMessageToArrays(Message message) {
            messages.add(message);
            messageIDs.add(message.getMessageID());
            messageHashes.add(message.getMessageHash());
            
            if (message.isSent()) {
                sentMessages.add(message);
            } else if (message.isStored()) {
                storedMessages.add(message);
            } else if (message.isDisregarded()) {
                disregardedMessages.add(message);
            }
        }

        // Unit test methods
        public String testSentMessagesArray() {
            StringBuilder sb = new StringBuilder();
            sb.append("Sent Messages array contains:\n");
            for (Message msg : sentMessages) {
                if (msg.isSent()) {
                    sb.append("\"").append(msg.getMessageText()).append("\"\n");
                }
            }
            return sb.toString();
        }
        
        public String testLongestMessage() {
            return displayLongestSentMessage();
        }
        
        public String testSearchMessageID() {
            return searchMessageByID("083884567");
        }

        public void storeMessagesToFile() {
            try (PrintWriter writer = new PrintWriter(new FileWriter("messages.txt"))) {
                writer.println("=== QUICKCHAT MESSAGE STORAGE ===");
                writer.println("Total messages sent: " + totalMessagesSent);
                writer.println("Total messages in system: " + messages.size());
                writer.println("=== MESSAGE DETAILS ===");
                
                for (int i = 0; i < messages.size(); i++) {
                    Message message = messages.get(i);
                    writer.println("Message " + (i + 1) + ":");
                    writer.println("  ID: " + message.getMessageID());
                    writer.println("  Number: " + message.getNumSent());
                    writer.println("  Recipient: " + message.getRecipient());
                    writer.println("  Message: " + message.getMessageText());
                    writer.println("  Hash: " + message.getMessageHash());
                    writer.println("  Status: " + 
                        (message.isSent() ? "SENT" : 
                         message.isStored() ? "STORED" : 
                         message.isDisregarded() ? "DISREGARDED" : "PENDING"));
                    writer.println("---");
                }
                
                JOptionPane.showMessageDialog(null, 
                    String.format("Messages stored to messages.txt\nTotal: %d messages", messages.size()),
                    "Storage Complete", JOptionPane.INFORMATION_MESSAGE);
                    
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, 
                    "Error storing messages: " + e.getMessage(),
                    "Storage Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        public int getTotalMessagesSent() {
            return totalMessagesSent;
        }

        public List<Message> getMessages() {
            return messages;
        }
        
        // Getters for arrays
        public List<Message> getSentMessages() { return sentMessages; }
        public List<Message> getDisregardedMessages() { return disregardedMessages; }
        public List<Message> getStoredMessages() { return storedMessages; }
        public List<String> getMessageHashes() { return messageHashes; }
        public List<String> getMessageIDs() { return messageIDs; }
    }

    // Validator class
    static class Validator {
        public static boolean isValidUsername(String username) {
            return username != null && username.length() >= 4 && username.contains("_");
        }

        public static boolean isValidPassword(String password) {
            if (password == null) return false;
            String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&+=]).{8,}$";
            return password.matches(regex);
        }

        public static boolean isValidCellphone(String phone) {
            return phone.matches("^(\\+27|0)[6-8][0-9]{8}$");
        }

        public static boolean isValidEmail(String email) {
            return email.matches("^[\\w-.]+@([\\w-]+\\.)+[\\w-]{2,4}$");
        }
    }

    // LoginSystem class
    public static class LoginSystem {
        final List<User> users = new ArrayList<>();
        private boolean loggedIn = false;
        private String currentUser = null;

        public boolean register(User user) {
            if (usernameExists(user.getUsername())) {
                return false;
            }
            users.add(user);
            return true;
        }

        public String getRegistrationErrors(User user, String rawPassword) {
            StringBuilder errors = new StringBuilder();

            if (!Validator.isValidUsername(user.getUsername())) {
                if (user.getUsername().length() < 4) {
                    errors.append("• Username must be at least 4 characters long.\n");
                }
                if (!user.getUsername().contains("_")) {
                    errors.append("• Username must contain an underscore (_).\n");
                }
            }

            if (!Validator.isValidPassword(rawPassword)) {
                errors.append("• Password must be at least 8 characters and include 1 uppercase, 1 number, and 1 special character (!@#$%^&+=).\n");
            }

            if (!Validator.isValidCellphone(user.getCellphone())) {
                errors.append("• Cellphone must be valid SA format: 0821234567 or +27821234567.\n");
            }

            if (!Validator.isValidEmail(user.getEmail())) {
                errors.append("• Email format is invalid.\n");
            }

            if (usernameExists(user.getUsername())) {
                errors.append("• Username already exists.\n");
            }

            return errors.length() == 0 ? null : errors.toString();
        }

        public boolean login(String username, String password) {
            String hashed = hashPassword(password);
            for (User user : users) {
                if (user.getUsername().equals(username)) {
                    if (user.getHashedPassword().equals(hashed)) {
                        loggedIn = true;
                        currentUser = username;
                        return true;
                    }
                }
            }
            return false;
        }

        public void logout() {
            loggedIn = false;
            currentUser = null;
        }

        public boolean isLoggedIn() {
            return loggedIn;
        }

        public String getCurrentUser() {
            return currentUser;
        }

        public boolean usernameExists(String username) {
            return users.stream().anyMatch(u -> u.getUsername().equals(username));
        }

        public boolean isPasswordCorrect(String username, String rawPassword) {
            String hashed = hashPassword(rawPassword);
            return users.stream()
                    .filter(u -> u.getUsername().equals(username))
                    .anyMatch(u -> u.getHashedPassword().equals(hashed));
        }

        public String hashPassword(String password) {
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte[] hashedBytes = md.digest(password.getBytes());
                StringBuilder sb = new StringBuilder();
                for (byte b : hashedBytes) {
                    sb.append(String.format("%02x", b));
                }
                return sb.toString();
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException("SHA-256 not supported");
            }
        }
    }

    // GUI section
    private final JFrame frame;
    private final JTextField usernameField;
    private final JTextField cellphoneField;
    private final JTextField emailField;
    private final JPasswordField passwordField;
    private final JButton registerButton;
    private final JButton loginButton;
    private final JButton messageButton;
    private final LoginSystem loginSystem = new LoginSystem();
    private final MessageSystem messageSystem = new MessageSystem();

    public LoginApp() {
        frame = new JFrame("Registration and Login");
        frame.setSize(400, 400);
        frame.setLayout(null);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(20, 20, 100, 25);
        frame.add(usernameLabel);
        usernameField = new JTextField();
        usernameField.setBounds(140, 20, 200, 25);
        frame.add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(20, 60, 100, 25);
        frame.add(passwordLabel);
        passwordField = new JPasswordField();
        passwordField.setBounds(140, 60, 200, 25);
        frame.add(passwordField);

        JLabel cellphoneLabel = new JLabel("Cellphone:");
        cellphoneLabel.setBounds(20, 100, 100, 25);
        frame.add(cellphoneLabel);
        cellphoneField = new JTextField();
        cellphoneField.setBounds(140, 100, 200, 25);
        frame.add(cellphoneField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(20, 140, 100, 25);
        frame.add(emailLabel);
        emailField = new JTextField();
        emailField.setBounds(140, 140, 200, 25);
        frame.add(emailField);

        registerButton = new JButton("Register");
        registerButton.setBounds(50, 190, 120, 30);
        registerButton.addActionListener(e -> handleRegister());
        frame.add(registerButton);

        loginButton = new JButton("Login");
        loginButton.setBounds(200, 190, 120, 30);
        loginButton.addActionListener(e -> handleLogin());
        frame.add(loginButton);

        messageButton = new JButton("Messaging");
        messageButton.setBounds(125, 240, 150, 30);
        messageButton.addActionListener(e -> handleMessaging());
        messageButton.setEnabled(false);
        frame.add(messageButton);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    private void handleRegister() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String cellphone = cellphoneField.getText().trim();
        String email = emailField.getText().trim();

        String hashedPassword = loginSystem.hashPassword(password);
        User user = new User(username, hashedPassword, cellphone, email);

        String validationErrors = loginSystem.getRegistrationErrors(user, password);
        if (validationErrors != null) {
            JOptionPane.showMessageDialog(frame,
                    "Registration failed.\n" + validationErrors,
                    "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean success = loginSystem.register(user);

        if (success) {
            JOptionPane.showMessageDialog(frame, "Successfully registered!");
            clearFields();
        } else {
            JOptionPane.showMessageDialog(frame,
                    "Registration failed.\nUsername already exists.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (!loginSystem.usernameExists(username)) {
            JOptionPane.showMessageDialog(frame,
                    "Login failed. Username not found.",
                    "Login Error", JOptionPane.ERROR_MESSAGE);
        } else if (!loginSystem.isPasswordCorrect(username, password)) {
            JOptionPane.showMessageDialog(frame,
                    "Login failed. Incorrect password.",
                    "Login Error", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(frame, "Login successful!");
            loginSystem.login(username, password);
            messageButton.setEnabled(true);
            clearFields();
        }
    }

    private void handleMessaging() {
        if (!loginSystem.isLoggedIn()) {
            JOptionPane.showMessageDialog(frame, "Please login first!");
            return;
        }

        // Welcome message
        JOptionPane.showMessageDialog(frame, "Welcome to QuickChat.");
        
        // Populate test data
        messageSystem.populateTestData();

        boolean running = true;
        while (running) {
            String[] options = {
                "Send Messages", 
                "Show recently sent messages",
                "Array Operations",
                "Run Unit Tests",
                "Quit"
            };
            int choice = JOptionPane.showOptionDialog(frame,
                    "Choose an option:",
                    "QuickChat Menu",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    options,
                    options[0]);

            switch (choice) {
                case 0: // Send Messages
                    handleSendMessages();
                    break;
                case 1: // Show recently sent messages
                    JOptionPane.showMessageDialog(frame, "Coming Soon.");
                    break;
                case 2: // Array Operations
                    handleArrayOperations();
                    break;
                case 3: // Run Unit Tests
                    runUnitTests();
                    break;
                case 4: // Quit
                case JOptionPane.CLOSED_OPTION:
                    running = false;
                    break;
            }
        }
    }

    private void handleSendMessages() {
        String numMessagesStr = JOptionPane.showInputDialog(frame, 
            "How many messages do you wish to enter?");
        
        if (numMessagesStr == null) return;
        
        try {
            int numMessages = Integer.parseInt(numMessagesStr);
            
            for (int i = 0; i < numMessages; i++) {
                JTextField recipientField = new JTextField();
                JTextArea messageArea = new JTextArea(5, 20);
                messageArea.setLineWrap(true);
                messageArea.setWrapStyleWord(true);
                
                JScrollPane scrollPane = new JScrollPane(messageArea);
                
                Object[] messageFields = {
                    "Recipient:", recipientField,
                    "Message (max 250 chars):", scrollPane
                };

                int option = JOptionPane.showConfirmDialog(frame, messageFields, 
                    "Message " + (i + 1), JOptionPane.OK_CANCEL_OPTION);
                
                if (option == JOptionPane.OK_OPTION) {
                    String recipient = recipientField.getText().trim();
                    String messageText = messageArea.getText().trim();
                    
                    Message message = messageSystem.createMessage(recipient, messageText);
                    messageSystem.processMessage(message);
                } else {
                    break;
                }
            }
            
            // Show total messages sent
            JOptionPane.showMessageDialog(frame, 
                "Total messages sent: " + messageSystem.getTotalMessagesSent());
            
            // Store messages to file
            messageSystem.storeMessagesToFile();
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Please enter a valid number.");
        }
    }

    private void handleArrayOperations() {
        String[] options = {
            "Display sent messages senders/recipients",
            "Display longest sent message", 
            "Search for message by ID",
            "Search messages by recipient",
            "Delete message by hash",
            "Display full report",
            "Back"
        };
        
        int choice = JOptionPane.showOptionDialog(frame,
                "Choose array operation:",
                "Array Operations",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);
        
        switch (choice) {
            case 0:
                String sentInfo = messageSystem.displaySentMessagesSendersRecipients();
                JOptionPane.showMessageDialog(frame, sentInfo);
                break;
            case 1:
                String longestMsg = messageSystem.displayLongestSentMessage();
                JOptionPane.showMessageDialog(frame, longestMsg);
                break;
            case 2:
                String searchID = JOptionPane.showInputDialog(frame, "Enter Message ID to search:");
                if (searchID != null && !searchID.trim().isEmpty()) {
                    String result = messageSystem.searchMessageByID(searchID.trim());
                    JOptionPane.showMessageDialog(frame, result);
                }
                break;
            case 3:
                String recipient = JOptionPane.showInputDialog(frame, "Enter recipient to search:");
                if (recipient != null && !recipient.trim().isEmpty()) {
                    String result = messageSystem.searchMessagesByRecipient(recipient.trim());
                    JOptionPane.showMessageDialog(frame, result);
                }
                break;
            case 4:
                String hash = JOptionPane.showInputDialog(frame, "Enter message hash to delete:");
                if (hash != null && !hash.trim().isEmpty()) {
                    String result = messageSystem.deleteMessageByHash(hash.trim());
                    JOptionPane.showMessageDialog(frame, result);
                }
                break;
            case 5:
                String report = messageSystem.displayFullReport();
                JTextArea textArea = new JTextArea(20, 50);
                textArea.setText(report);
                textArea.setEditable(false);
                JScrollPane scrollPane = new JScrollPane(textArea);
                JOptionPane.showMessageDialog(frame, scrollPane, "Full Message Report", JOptionPane.INFORMATION_MESSAGE);
                break;
        }
    }

    private void runUnitTests() {
        StringBuilder testResults = new StringBuilder();
        testResults.append("=== UNIT TEST RESULTS ===\n\n");
        
        // Test 1: Sent Messages array correctly populated
        testResults.append("TEST 1: Sent Messages Array\n");
        testResults.append("Expected: 'Did you get the cake?', 'It is dinner time !!'\n");
        testResults.append("Actual:\n");
        testResults.append(messageSystem.testSentMessagesArray());
        testResults.append("\n");
        
        // Test 2: Display longest message
        testResults.append("TEST 2: Longest Sent Message\n");
        testResults.append("Expected: 'Where are you? You are late! I have asked you to be on time.'\n");
        testResults.append("Actual:\n");
        testResults.append(messageSystem.testLongestMessage());
        testResults.append("\n");
        
        // Test 3: Search for message ID
        testResults.append("TEST 3: Search Message by ID\n");
        testResults.append("Expected: Message with ID '083884567'\n");
        testResults.append("Actual:\n");
        testResults.append(messageSystem.testSearchMessageID());
        testResults.append("\n");
        
        JTextArea textArea = new JTextArea(20, 60);
        textArea.setText(testResults.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        JOptionPane.showMessageDialog(frame, scrollPane, "Unit Test Results", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
        cellphoneField.setText("");
        emailField.setText("");
    }

    public static void main(String[] args) {
        new LoginApp();
    }
}